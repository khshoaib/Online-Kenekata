﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMS_Project.Models
{
    public static class TemData
    {
        public static int EmpID { get; set; }
    }
}